# Completed controlled mechanism study and paper

**When Do Linear-Cost Diffusion Passes Help with Long Contexts?**

- PDF: build/Long_RWKV_ICLR2027.pdf
- Source: Long_RWKV_ICLR2027.tex
- Rebuild: bash build_focused.sh

The controlled 16K study supports the focused mechanism claim. Distance-balanced training reduces far-context conditional error relative to near-only training in all three adaptation seeds. The mean paired reduction is **6.051 nats [5.392, 6.735]**, conditional on the three observed adaptation seeds and selected starting lineage. Accurate, selective evidence-flip responses and an equal-call contrast within 0.000124 nats of the theoretical 4log2 prediction support the account.

All three balanced models pass the matched eight-problem empirical quality–cost certificate under the predeclared 1.5-second mean budget. Recurrent two-call requests take about 1.30 seconds versus 2.00 seconds for attention. One near-only model also passes the aggregate certificate despite near-chance far-context predictions; this exception remains explicit.

This is a controlled synthetic study, not a broad language-model benchmark or a claim of conference-level novelty. All adaptations share one selected checkpoint. Whole instruction/evidence blocks move, the structure catalog was previously observed, and cost comparisons are restricted to the declared implementations and policies. No memory advantage or superiority over cached causal decoding is established.

## Final evidence

| Evidence | Artifact |
|---|---|
|All 1008 exact conditions, 3024 endpoint laws, 2520 RWKV timed requests|results/distance_intervention/FINAL_REPORT.md and final_report.json|
|Six matched certificates and 360 attention timings|results/distance_intervention_cost/BUDGET_REPORT.md and budget_certificates.json|
|Main mechanism figure|results/distance_intervention/mechanism_distance_paper.pdf|
|All secondary cells|results/distance_intervention/paper_secondary_table.tex|
|Claim audit|results/paper_audit/distance_intervention_claim_audit.md|
|Independent numeric, hash, manuscript and live-resource audit|results/distance_intervention/delivery_audit.json|
|Final PDF visual review|results/paper_audit/distance_intervention_visual_review.json|
|All 18 jobs and utilization|results/distance_intervention/resource_audit.json|
|Peak queued+running allocation|results/distance_intervention/capacity_timeline_audit.json|

All six training runs reached 600 updates with matched 315,283,200 input tokens/run. Follow-up runtime totals 106.34 scheduler H100-hours, including qualification, evaluation and the three failed launches before model loading. This excludes earlier selected-checkpoint training. Peak reservation was 48 H100s, split 32 primary + 16 extra, max 8/job. All jobs are terminal; the final campaign census is zero.

Steady training GPU busy time was 95.6–96.3%; memory occupancy was about 25.9%. GPU busy is not achieved FLOP utilization. The work follows the later fastest-completion priority and does not claim 80% memory occupancy.

Frozen protocols are under theory_mvp/distance_intervention/. Immutable source/job/checkpoint receipts and raw-output hashes are retained. No failed seed or position was removed; no outcome selected the terminal step or changed the experiment or analysis.

## Earlier evidence retained

The preceding 640-condition context-adaptation study failed its 16K criterion and remains in the appendix. Its cost report is under results/posterior_context_cost/ and exact report under results/posterior_context_final/. Earlier short-task seed failures, lookup-adaptation failures and auxiliary causal timings are also retained. Historical manifests describe their original snapshots; the new final manifest is results/paper_audit/distance_intervention_delivery_manifest.json.
