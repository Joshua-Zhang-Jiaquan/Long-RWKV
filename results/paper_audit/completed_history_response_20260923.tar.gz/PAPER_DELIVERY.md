# Updated paper and exhaustive mechanism audit

**When Do Linear-Cost Diffusion Passes Help with Long Contexts?**

- PDF: build/Long_RWKV_ICLR2027.pdf (16 pages; main text and references through page8).
- Source: Long_RWKV_ICLR2027.tex. Rebuild: bash build_focused.sh.
- Latest scientific review: results/history_response/CLAIM_AUDIT.md.

## New evidence and theory

The exhaustive follow-up evaluates all 16 target histories and four syndrome flips for every existing primary problem, position and checkpoint: 672 conditions and 43,008 paired interventions. Far paired correct-target error falls by **1.477852 nats [1.327451,1.637084]**, conditional on the three observed adaptation seeds and selected starting lineage. All three seed effects are positive.

The appendix derives an exact link between paired-flip CE and conditional error, plus the conservative sufficient condition **E_first + 8 mean_pair_CE < 4 ln2** for the original two-pass law to beat every one-call product predictor. Every balanced model/problem/position cell passes this criterion. It is elementary, sufficient rather than necessary, and not a guarantee for natural language or the full counterfactual prompt.

The broader probe also discovers **three correct-to-incorrect changes among 55,296 unaffected-target comparisons**. Rare probability shifts reach 0.992. The abstract and main results now state this limitation: the evidence supports improved average conditional prediction and mostly selective responses, not uniform selectivity. The diagnosis of collateral errors is explicitly post hoc.

This audit reuses 32 problems and seven checkpoints. It is not independent replication; all adaptations still share one selected starting lineage. The synthetic-task, observed-structure-catalog, public-block-distance and implementation-specific cost limitations remain.

## Verification and artifacts

| Artifact | Location |
|---|---|
|Frozen protocol and source/checkpoint hashes|theory_mvp/history_response/DESIGN.md and FROZEN.json|
|All seven exact results and paired inference|results/history_response/exact_*.json, report.json and REPORT.md|
|Response-bound certificate|results/history_response/response_corollary.json|
|Post hoc collateral diagnosis|results/history_response/collateral_diagnostic.json|
|Standalone figure|results/history_response/exhaustive_response.pdf|
|Independent arithmetic/provenance/PDF audit|results/history_response/delivery_audit.json|
|Visual review of all 16 pages|results/paper_audit/history_response_visual_review.json|
|Scheduler intervals and utilization|results/history_response/resource_audit.json|
|Latest delivery manifest|results/paper_audit/history_response_delivery_manifest.json|

34 CPU tests and 384 native-layout checks passed before submission. Every archived probe and stage error reconciles within 8.30e-5, below the frozen 1e-4 tolerance. Independent raw-probability recomputation reproduces the reported arithmetic within 7.11e-15. The PDF builds without undefined references or overfull boxes and has been visually reviewed.

Seven successful evaluation jobs use **11.89 additional H100-hours**, with no retraining or automatic retries. Reservation peaks at 48 H100s (primary 32 + extra 16, max 8/job); all jobs are terminal and no GPUs remain reserved. Whole-job GPU busy is 84.0–88.0%; mean memory occupancy is 8.7–9.0%. GPU busy is not achieved FLOP utilization; the earlier memory target is not met under the later fastest-completion priority.

## Previous evidence and preserved delivery

The matched training study remains unchanged: all six fixed 600-update runs, 1008 exact conditions, 6.051-nat primary error reduction, and all three balanced 1.5-second empirical quality–cost certificates. Recurrent two-call time is about 1.30s versus 2.00s for the declared attention implementation. The preceding failed extrapolation and learning-seed experiments remain in the appendix. The earlier matched study used 106.34 H100-hours, excluding earlier checkpoint training.

A methods wording error is corrected: whole-record RWKV packing gives 16,383 primary prefix tokens, whereas the attention cost prefixes contain 16,384 under the same requested 16K budget. Frozen inputs and numerical results have not changed.

The verified pre-follow-up delivery, including its original PDF/source and 91 manifest-pinned files, is preserved in results/paper_audit/completed_distance_study_20260922.tar.gz. Its original manifest describes that historical snapshot; the latest manifest describes the updated paper.
